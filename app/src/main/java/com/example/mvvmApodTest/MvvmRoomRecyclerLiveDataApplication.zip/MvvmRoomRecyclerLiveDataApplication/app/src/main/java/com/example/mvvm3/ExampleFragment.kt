package com.example.mvvm3

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.mvvm3.databinding.FragmentExampleBinding


public class ExampleFragment : Fragment(R.layout.fragment_example) {
    private var binding: FragmentExampleBinding? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentExampleBinding.inflate(inflater, container, false)
        return binding?.root

    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}