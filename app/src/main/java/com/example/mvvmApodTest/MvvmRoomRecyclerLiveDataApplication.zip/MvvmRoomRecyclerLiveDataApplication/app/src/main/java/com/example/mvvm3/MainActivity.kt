package com.example.mvvm3

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.mvvm3.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private var binding: ActivityMainBinding? = null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding?.root
        setContentView(view)

        if (savedInstanceState == null) {

        }

        binding?.nameTextView?.text = "I'm use viewBinding"
        binding?.pressButton?.setOnClickListener {
            Log.d(
                this.localClassName.toString(),
                " Im press button "
            )
            binding?.nameTextView?.text = "Im press button"
        }


    }
}
