package com.example.mvvm3


import org.koin.android.ext.koin.androidApplication
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

object DependencyModule {
    val searchPictureModule = module{
        factory { ApiClient.getApiRetrofitClient()?.create(ApiInterface::class.java) }
        factory { SearchPictureRepositoryImpl(get()) as SearchPictureRepository }
        factory { SearchPictureInteractorImpl() as SearchPictureInteractor }
        viewModel { SearchPictureViewModel() }
        viewModel { SearchPictureViewModel2() }
        factory { SearchPictureAdapter() }
    }
}