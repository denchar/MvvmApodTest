package com.example.mvvm3

import androidx.lifecycle.MutableLiveData



data class ViewState(val pictureOfDay : PictureOfDayModel,
                     val errorMessage :String,
                     val listWithDate :List<String>)
