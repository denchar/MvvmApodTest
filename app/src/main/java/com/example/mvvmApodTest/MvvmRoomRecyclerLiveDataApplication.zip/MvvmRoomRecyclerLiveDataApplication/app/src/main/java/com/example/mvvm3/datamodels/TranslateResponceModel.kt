package com.example.mvvm3

data class TranslateResponceModel(val code: String, val lang: String, val text: List<String>) {
}